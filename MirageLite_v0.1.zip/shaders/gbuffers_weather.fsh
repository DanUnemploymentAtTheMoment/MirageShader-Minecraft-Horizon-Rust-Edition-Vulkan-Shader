#version 330 compatibility
uniform sampler2D texture;
in vec4 vColor;
in vec2 vTex;
in vec2 vLm;
in vec3 vViewPos;
void main() {
    vec4 t = texture2D(texture, vTex);
    if (t.a < 0.05) discard;
    float k = 0.35 + 0.65 * vLm.y;
    gl_FragData[0] = vec4(sqrt(vec3(0.55, 0.62, 0.75) * k * 0.25), t.a * 0.45);
}

/* DRAWBUFFERS:0 */
