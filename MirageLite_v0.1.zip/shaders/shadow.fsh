#version 330 compatibility
#include "lib/settings.glsl"
uniform sampler2D texture;
in vec2 vTex;
in vec4 vColor;
void main() {
    vec4 t = texture2D(texture, vTex);
    if (t.a * vColor.a < 0.2) discard;
    gl_FragData[0] = vec4(t.rgb * vColor.rgb, 1.0);
}
