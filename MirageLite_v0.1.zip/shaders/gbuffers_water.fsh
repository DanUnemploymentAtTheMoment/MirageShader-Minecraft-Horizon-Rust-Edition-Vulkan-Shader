#version 330 compatibility
#include "lib/settings.glsl"
#include "lib/gbuf_head.glsl"
#include "lib/common.glsl"
#include "lib/sky.glsl"
#include "lib/lighting.glsl"

uniform vec3 cameraPosition;
uniform float frameTimeCounter;

void main() {
    vec3 vp = vViewPos;
    vec3 N = faceNormal(vp);
    vec4 c = texture2D(texture, vTex) * vColor;

    // No block IDs without flat draws, so water is told from glass by its biome tint (glass vertex colour is white).
    bool isWater = max(abs(vColor.r - vColor.g), abs(vColor.g - vColor.b)) > 0.04;

    vec3 albedo = c.rgb * c.rgb;
    vec3 col;
    float alpha = c.a;

    if (isWater) {
        vec3 V = normalize(vp);
        vec3 feet = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz;
        vec2 p = (feet + cameraPosition).xz;
        float t = frameTimeCounter;

        // Three travelling sine waves, analytic slope: a rippled normal for the price of 3 cosines.
        float a1 = dot(p, vec2(0.80, 0.60)) * 1.1 + t * 1.3;
        float a2 = dot(p, vec2(-0.50, 0.87)) * 2.3 - t * 1.7;
        float a3 = dot(p, vec2(0.96, -0.28)) * 4.7 + t * 2.3;
        vec2 g = vec2(0.80, 0.60) * cos(a1) * 0.35 + vec2(-0.50, 0.87) * cos(a2) * 0.18 + vec2(0.96, -0.28) * cos(a3) * 0.07;
        g *= 0.30 / (1.0 + length(vp) * 0.02);            // calmer with distance: no far-field sparkle

        vec3 Nw = mat3(gbufferModelViewInverse) * N;
        if (Nw.y > 0.5) {
            vec3 nw = normalize(vec3(-g.x, 1.0, -g.y));
            N = normalize(mat3(gbufferModelView) * nw);
        }

        // Reflection = the analytic sky, no screen-space tracing at all.
        vec3 R = reflect(V, N);
        vec3 Rw = mat3(gbufferModelViewInverse) * R;
        Rw.y = max(Rw.y, 0.03);
        Rw = normalize(Rw);
        vec3 sunW = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
        vec3 moonW = normalize((gbufferModelViewInverse * vec4(moonPosition, 0.0)).xyz);
        vec3 refl = skyGradient(Rw, sunW, moonW, rainStrength, 1.0);
        refl *= mix(0.06, 1.0, smoothstep(0.25, 0.9, vLm.y));   // no sky in caves and under roofs

        float f = 0.03 + 0.97 * pow(1.0 - clamp(dot(N, -V), 0.0, 1.0), 5.0);
        vec3 diffuse = shade(albedo, N, vp, vLm, 0.0);
        col = mix(diffuse, refl, f);
        alpha = clamp(0.58 + f * 0.40, 0.0, 1.0);
    } else {
        col = shade(albedo, N, vp, vLm, 0.0);
    }

    gl_FragData[0] = vec4(enc(col), alpha);
}

/* DRAWBUFFERS:0 */
