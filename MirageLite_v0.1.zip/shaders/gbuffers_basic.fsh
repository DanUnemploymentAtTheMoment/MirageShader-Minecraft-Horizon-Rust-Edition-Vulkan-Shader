#version 330 compatibility
in vec4 vColor;
void main() {
    gl_FragData[0] = vec4(sqrt(vColor.rgb * vColor.rgb * 0.25), vColor.a);
}

/* DRAWBUFFERS:0 */
