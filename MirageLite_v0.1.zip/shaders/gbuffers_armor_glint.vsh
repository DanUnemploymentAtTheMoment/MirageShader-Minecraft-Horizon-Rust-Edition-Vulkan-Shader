#version 330 compatibility
out vec4 vColor;
out vec2 vTex;
void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    vColor = gl_Color;
    vTex = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
}
