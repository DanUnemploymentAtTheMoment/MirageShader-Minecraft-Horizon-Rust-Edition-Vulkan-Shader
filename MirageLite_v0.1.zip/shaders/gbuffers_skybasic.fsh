#version 330 compatibility
void main() {
    gl_FragData[0] = vec4(0.0);
}

/* DRAWBUFFERS:0 */
