// Shared main() for terrain, entities, hand and particles. Define one MODE_* first.
void main() {
    vec3 N = faceNormal(vViewPos);                 // derivatives first, before any discard

    vec4 tex = texture2D(texture, vTex);
    vec4 c = tex * vColor;
    if (c.a < 0.1) discard;                         // Horizon does no alpha test for packs

    #ifdef MODE_ENTITY
    c.rgb = mix(c.rgb, entityColor.rgb, entityColor.a);
    #endif

    vec3 albedo = c.rgb * c.rgb;                    // sRGB -> linear, the cheap way
    albedo *= 1.0 - wetness * 0.25 * smoothstep(0.7, 0.95, vLm.y);

    vec3 col = shade(albedo, N, vViewPos, vLm, 0.0);
    gl_FragData[0] = vec4(enc(col), vLm.y);         // alpha carries skylight for the composite's fog
}

/* DRAWBUFFERS:0 */
