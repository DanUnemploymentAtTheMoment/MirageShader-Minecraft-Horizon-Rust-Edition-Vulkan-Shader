// Small shared helpers. No uniforms in here on purpose.
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// 8-bit friendly storage: sqrt curve and a x4 headroom for HDR-ish values.
vec3 enc(vec3 c) { return sqrt(clamp(c * 0.25, 0.0, 1.0)); }
vec3 dec(vec3 e) { return e * e * 4.0; }

// Interleaved gradient noise: free blue-ish dither, no texture needed.
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.x, p.y, p.x) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm2(vec2 p) { return vnoise(p) * 0.65 + vnoise(p * 2.13 + vec2(7.7, 3.1)) * 0.35; }
