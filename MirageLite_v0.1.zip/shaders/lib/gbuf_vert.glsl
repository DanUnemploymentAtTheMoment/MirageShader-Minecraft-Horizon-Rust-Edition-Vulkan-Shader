// Shared vertex stage for every lit gbuffers program.
out vec4 vColor;
out vec2 vTex;
out vec2 vLm;
out vec3 vViewPos;

void main() {
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    vViewPos = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
    vColor = gl_Color;
    vTex = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vec2 l = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    vLm = vec2(clamp(l.x * 33.05 / 32.0 - 0.0328125, 0.0, 1.0),
               clamp(l.y * 33.75 / 32.0 - 0.0328125, 0.0, 1.0));
}
