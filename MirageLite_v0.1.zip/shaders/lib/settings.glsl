// ---- MirageLite options (shown in the shader options screen when the loader supports it) ----
#define SHADOWS                 // Real sun shadows: one extra depth pass, 4 filtered taps. Off = fake shadows from skylight (much cheaper)
#define AMBIENT_OCCLUSION       // 4-tap depth AO in the composite pass
#define CLOUDS                  // Procedural sky clouds (only drawn on sky pixels)
#define GODRAYS                 // 6-tap sun shafts, only near the sun
#define BLOOM                   // Soft glow from mipmaps (almost free)
#define SHARPEN                 // 4-tap sharpen, helps when the port renders below native resolution
#define EXPOSURE 1.0            //[0.6 0.7 0.8 0.9 1.0 1.15 1.3 1.5]
#define SATURATION 1.10         //[0.8 0.9 1.0 1.1 1.2 1.3]
#define FOG_DENSITY 1.0         //[0.0 0.5 1.0 1.5 2.0]

// Fixed values (read by the loader from the program files)
const int   shadowMapResolution = 1024;
const float shadowDistance      = 72.0;
const float sunPathRotation     = -25.0;
#define SHADOW_DISTORT 0.85
