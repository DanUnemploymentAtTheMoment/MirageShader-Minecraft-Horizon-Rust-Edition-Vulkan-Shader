// Fake-GI lighting for forward-shaded geometry.
// Needs these uniforms declared before the include:
//   gbufferModelView, gbufferModelViewInverse, shadowModelView, shadowProjection,
//   sunPosition, moonPosition, rainStrength, heldBlockLightValue, shadowtex0 (sampler2DShadow)

float shadowVis(vec3 vp, vec3 N, float ndl) {
    vec3 feet = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz;
    vec3 Nw = mat3(gbufferModelViewInverse) * N;
    feet += Nw * (0.04 + 0.0012 * length(vp));               // normal-offset bias
    vec3 sp = (shadowProjection * (shadowModelView * vec4(feet, 1.0))).xyz;
    sp.xy /= (1.0 - SHADOW_DISTORT) + length(sp.xy) * SHADOW_DISTORT;
    sp = sp * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z > 1.0) return 1.0;
    sp.z -= 0.0005 + 0.0015 * (1.0 - ndl);

    // 4 taps on the hardware comparison sampler (each one is already bilinear-filtered) with a per-pixel rotation.
    float texel = 1.0 / float(shadowMapResolution);
    float a = ign(gl_FragCoord.xy) * 6.2831853;
    vec2 r1 = vec2(cos(a), sin(a)) * texel * 1.4;
    vec2 r2 = vec2(-r1.y, r1.x);
    float s = 0.0;
    s += shadow2DLod(shadowtex0, vec3(sp.xy + r1, sp.z), 0.0).x;
    s += shadow2DLod(shadowtex0, vec3(sp.xy - r1, sp.z), 0.0).x;
    s += shadow2DLod(shadowtex0, vec3(sp.xy + r2, sp.z), 0.0).x;
    s += shadow2DLod(shadowtex0, vec3(sp.xy - r2, sp.z), 0.0).x;
    return s * 0.25;
}

// Returns linear HDR colour. emit adds self-glow (multiplied by albedo).
vec3 shade(vec3 albedo, vec3 N, vec3 vp, vec2 lm, float emit) {
    vec3 sunW = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    float sh = sunW.y;
    float day = dayFactor(sh);
    float sunUp  = smoothstep(-0.04, 0.10, sh);
    float moonUp = 1.0 - smoothstep(-0.14, -0.04, sh);

    vec3 sunCol  = sunColorAt(sh) * sunUp * 2.6;
    vec3 moonCol = vec3(0.30, 0.42, 0.80) * 0.07 * moonUp;
    vec3 Lv = normalize(sh > -0.04 ? sunPosition : moonPosition);
    vec3 Lc = sunCol + moonCol;

    float ndl = dot(N, Lv);
    float diff = clamp((ndl + 0.15) / 1.15, 0.0, 1.0);      // wrapped diffuse: softer terminator, fake subsurface

    // Sun visibility: skylight-based fake shadow, replaced by the shadow map up close.
    float skyExp = smoothstep(0.78, 0.96, lm.y);
    float vis = skyExp;
    #ifdef SHADOWS
    float dist = length(vp);
    float fade = smoothstep(shadowDistance * 0.70, shadowDistance * 0.92, dist);
    if (diff > 0.0 && fade < 1.0 && (sunUp + moonUp) > 0.0) {
        float s = shadowVis(vp, N, max(ndl, 0.0));
        s *= smoothstep(0.30, 0.65, lm.y);
        vis = mix(s, skyExp, fade);
    }
    #endif
    vis *= 1.0 - rainStrength * 0.85;

    // Hemispheric sky ambient + ground bounce (the cheap stand-in for global illumination).
    vec3 Nw = mat3(gbufferModelViewInverse) * N;
    float up = Nw.y * 0.5 + 0.5;
    float dusk = exp(-sh * sh * 28.0);
    vec3 ambTop = mix(vec3(0.020, 0.032, 0.075), vec3(0.34, 0.50, 0.88), day);
    ambTop += vec3(0.20, 0.10, 0.10) * dusk * 0.5;
    vec3 ambBot = ambTop * 0.35 + sunCol * 0.06 + vec3(0.006, 0.008, 0.016);
    vec3 amb = mix(ambBot, ambTop, up);
    amb *= mix(0.025, 1.0, lm.y * lm.y);
    amb = mix(amb, vec3(luma(amb)), rainStrength * 0.6) * (1.0 - rainStrength * 0.3);

    // Fill light from the side opposite the sun: fakes colour bounce off nearby surfaces.
    vec3 Lwh = normalize(vec3(sunW.x, 0.0, sunW.z) + vec3(0.0001));
    vec3 fill = sunCol * 0.09 * max(dot(Nw, -Lwh), 0.0) * lm.y;

    // Torches: warm, soft falloff curve with a hot core.
    float tl = lm.x;
    vec3 torch = vec3(1.0, 0.50, 0.18) * (pow(tl, 4.0) * 1.6 + pow(tl, 12.0) * 1.2);

    // Held light
    float hl = float(heldBlockLightValue);
    float hf = clamp(1.0 - length(vp) / max(hl, 1.0), 0.0, 1.0);
    vec3 held = vec3(1.0, 0.55, 0.22) * hf * hf * step(0.5, hl) * 1.5;

    vec3 light = Lc * diff * vis + amb + fill + torch + held;
    vec3 col = albedo * light;

    // Fake emissives: bright pixels on faces that sit at full block light (torches, lanterns, glowstone...).
    float em = smoothstep(0.95, 0.99, lm.x) * smoothstep(0.55, 0.85, luma(albedo));
    col += albedo * (em * 1.6 + emit);
    return col;
}

vec3 faceNormal(vec3 vp) {
    vec3 n = normalize(cross(dFdx(vp), dFdy(vp)));
    return dot(n, vp) > 0.0 ? -n : n;   // always face the camera, whatever the API's Y flip does to the cross product
}
