// Analytic sky: gradient + sunset + Mie glow + sun/moon + stars, and a cheap cloud layer.
// All directions are world-aligned (y up).
vec3 sunColorAt(float sh) {
    float k = smoothstep(0.0, 0.5, sh);
    return mix(vec3(1.0, 0.42, 0.16), vec3(1.0, 0.92, 0.78), k);
}
float dayFactor(float sh) { return smoothstep(-0.10, 0.20, sh); }

// fullAmt = 1 draws sun disc and stars, 0 gives just the haze colour (used for fog and water reflections of the horizon).
vec3 skyGradient(vec3 d, vec3 sunD, vec3 moonD, float rain, float fullAmt) {
    float sh = sunD.y;
    float day = dayFactor(sh);
    float dusk = exp(-sh * sh * 28.0);
    float h = clamp(d.y, 0.0, 1.0);
    float t = pow(1.0 - h, 3.2);

    vec3 zenith  = mix(vec3(0.004, 0.008, 0.022), vec3(0.075, 0.20, 0.52), day);
    vec3 horizon = mix(vec3(0.014, 0.024, 0.050), vec3(0.42, 0.58, 0.80), day);
    vec3 col = mix(zenith, horizon, t);

    // Sunset / sunrise: warm band toward the sun's side of the horizon, faint violet above it.
    float az = dot(normalize(d.xz + vec2(0.0001)), normalize(sunD.xz + vec2(0.0001))) * 0.5 + 0.5;
    col += vec3(1.0, 0.38, 0.12) * dusk * (0.15 + 0.85 * az) * t * 0.9;
    col += vec3(0.10, 0.04, 0.10) * dusk * (1.0 - t) * 0.5;

    // Forward scattering glow around the sun (the "Mie" look, three cheap lobes).
    float mu = max(dot(d, sunD), 0.0);
    float sunVis = smoothstep(-0.12, 0.05, sh) * (1.0 - rain * 0.85);
    vec3 sc = sunColorAt(sh);
    col += sc * (pow(mu, 6.0) * 0.10 + pow(mu, 48.0) * 0.35 + pow(mu, 400.0) * 1.4) * sunVis;
    col += sc * smoothstep(0.99935, 0.9997, mu) * 14.0 * sunVis * fullAmt;

    // Moon
    float mm = max(dot(d, moonD), 0.0);
    float moonVis = smoothstep(-0.10, 0.05, moonD.y) * (1.0 - 0.8 * day) * (1.0 - rain);
    col += vec3(0.70, 0.80, 1.00) * (pow(mm, 64.0) * 0.05 + smoothstep(0.9993, 0.9997, mm) * 3.0 * fullAmt) * moonVis;

    // Stars: hashed cells on the view direction, round-ish, night only.
    float night = (1.0 - day) * (1.0 - day) * (1.0 - rain);
    if (night > 0.01 && fullAmt > 0.5 && d.y > 0.0) {
        vec3 g = d * 420.0;
        vec3 id = floor(g);
        vec3 f = fract(g) - 0.5;
        float hs = hash12(id.xz + id.y * 57.0);
        float star = step(0.9965, hs) * (1.0 - smoothstep(0.1, 0.5, length(f)));
        col += vec3(0.8, 0.9, 1.0) * star * (hs - 0.9965) * 300.0 * night * smoothstep(0.0, 0.2, d.y);
    }

    // Rain: grey and flat
    col = mix(col, vec3(luma(col)) * 0.75 + 0.01, rain * 0.75);
    return col;
}

// Cheap clouds: one plane, 2 noise octaves, and a second noise tap shifted toward the sun to fake self-shadowing.
// Returns rgb + coverage alpha.
vec4 cloudLayer(vec3 d, vec3 camPos, vec3 sunD, float time, float rain, vec3 ambient) {
    if (d.y < 0.02) return vec4(0.0);
    float H = 220.0;
    float dist = (H - camPos.y) / d.y;
    if (dist < 0.0) return vec4(0.0);

    vec2 p = (camPos.xz + d.xz * dist) * 0.0035 + vec2(time * 0.006, time * 0.002);
    float n = fbm2(p);
    float cov = 0.52 - rain * 0.14;
    float a = smoothstep(cov, cov + 0.22, n);
    if (a <= 0.002) return vec4(0.0);

    float sh = sunD.y;
    vec2 toSun = normalize(sunD.xz + vec2(0.0001)) * (0.03 + 0.05 * (1.0 - clamp(sh, 0.0, 1.0)));
    float ns = fbm2(p + toSun);
    float tauS = smoothstep(cov, cov + 0.30, ns);
    float lit = exp(-tauS * 1.6);

    float sunUp = smoothstep(-0.05, 0.15, sh);
    vec3 sunL = sunColorAt(sh) * sunUp * 3.0;
    float mu = max(dot(d, sunD), 0.0);
    float silver = pow(mu, 10.0) * (1.0 - a) * 1.5;

    vec3 col = ambient * 0.9 + sunL * (lit * 0.75 + silver);
    col = mix(col, vec3(luma(col)) * 0.55, rain * 0.8);

    float fade = smoothstep(0.02, 0.22, d.y);
    return vec4(col, a * fade * 0.92);
}
