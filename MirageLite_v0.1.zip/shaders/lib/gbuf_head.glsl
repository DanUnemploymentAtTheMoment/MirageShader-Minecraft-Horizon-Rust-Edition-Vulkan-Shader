// Shared declarations for lit fragment programs (include after settings.glsl).
uniform sampler2D texture;
uniform sampler2DShadow shadowtex0;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform float rainStrength;
uniform float wetness;
uniform int heldBlockLightValue;
uniform vec4 entityColor;

in vec4 vColor;
in vec2 vTex;
in vec2 vLm;
in vec3 vViewPos;

