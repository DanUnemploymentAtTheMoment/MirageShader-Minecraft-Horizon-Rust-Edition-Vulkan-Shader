#version 330 compatibility
#include "lib/settings.glsl"
out vec2 vTex;
out vec4 vColor;
void main() {
    gl_Position = ftransform();
    gl_Position.xy /= (1.0 - SHADOW_DISTORT) + length(gl_Position.xy) * SHADOW_DISTORT;
    vTex = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    vColor = gl_Color;
}
