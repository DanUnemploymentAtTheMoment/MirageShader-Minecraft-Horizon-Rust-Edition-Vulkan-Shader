#version 330 compatibility
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
out vec2 texcoord;
out vec3 sunW;
out vec3 moonW;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.st;
    sunW = normalize((gbufferModelViewInverse * vec4(sunPosition, 0.0)).xyz);
    moonW = normalize((gbufferModelViewInverse * vec4(moonPosition, 0.0)).xyz);
}
