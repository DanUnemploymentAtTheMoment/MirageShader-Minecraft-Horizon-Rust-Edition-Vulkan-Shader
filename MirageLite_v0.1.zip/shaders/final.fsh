#version 330 compatibility
#include "lib/settings.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

// Bloom reads blurred mip levels of the scene: a wide glow for four texture reads.
const bool colortex0MipmapEnabled = true;

in vec2 texcoord;

#include "lib/common.glsl"

vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }

void main() {
    vec2 px = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    vec3 e = texture2D(colortex0, texcoord).rgb;

    #ifdef SHARPEN
    vec3 avg = texture2D(colortex0, texcoord + vec2(px.x, 0.0)).rgb + texture2D(colortex0, texcoord - vec2(px.x, 0.0)).rgb
             + texture2D(colortex0, texcoord + vec2(0.0, px.y)).rgb + texture2D(colortex0, texcoord - vec2(0.0, px.y)).rgb;
    e = max(e + (e - avg * 0.25) * 0.28, 0.0);
    #endif

    vec3 col = dec(e);

    #ifdef BLOOM
    vec3 b = dec(textureLod(colortex0, texcoord, 4.0).rgb);
    b += dec(textureLod(colortex0, texcoord + px * 6.0, 5.0).rgb);
    b += dec(textureLod(colortex0, texcoord - px * 6.0, 5.0).rgb);
    b *= (1.0 / 3.0);
    col += b * clamp(luma(b) * 0.6, 0.0, 1.0) * 0.45;
    #endif

    col *= 0.75 * EXPOSURE;
    col = aces(col);
    col = mix(vec3(luma(col)), col, SATURATION);

    vec2 q = texcoord - 0.5;
    col *= 1.0 - dot(q, q) * 0.45;                    // light vignette

    col = pow(col, vec3(0.4545));
    col += (ign(gl_FragCoord.xy) - 0.5) / 255.0;      // dither: hides the 8-bit banding in gradients

    gl_FragColor = vec4(col, 1.0);
}
