#version 330 compatibility
uniform sampler2D texture;
in vec4 vColor;
in vec2 vTex;
void main() {
    vec4 t = texture2D(texture, vTex) * vColor;
    gl_FragData[0] = vec4(sqrt(t.rgb * t.rgb * 0.5 * 0.25), 1.0);
}

/* DRAWBUFFERS:0 */
