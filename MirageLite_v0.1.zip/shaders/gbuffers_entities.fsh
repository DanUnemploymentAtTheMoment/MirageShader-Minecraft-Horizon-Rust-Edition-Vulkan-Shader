#version 330 compatibility
#define MODE_ENTITY
#include "lib/settings.glsl"
#include "lib/gbuf_head.glsl"
#include "lib/common.glsl"
#include "lib/sky.glsl"
#include "lib/lighting.glsl"
#include "lib/gbuf_main.glsl"
