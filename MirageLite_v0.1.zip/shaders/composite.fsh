#version 330 compatibility
#include "lib/settings.glsl"

// Everything that makes the picture look "expensive" happens here, once per pixel, from colour + depth only:
// sky, clouds, aerial-perspective fog, depth AO, sun shafts, underwater absorption.

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform int isEyeInWater;

in vec2 texcoord;
in vec3 sunW;
in vec3 moonW;

#include "lib/common.glsl"
#include "lib/sky.glsl"

float linZ(float d) { return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near)); }

void main() {
    vec4 src = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    vec4 vp4 = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec3 vp = vp4.xyz / vp4.w;
    vec3 dirV = normalize(vp);
    vec3 dirW = normalize(mat3(gbufferModelViewInverse) * dirV);

    float day = dayFactor(sunW.y);
    vec3 col;
    float dist;

    if (depth >= 1.0) {
        // ---- Sky pixel: the analytic sky replaces whatever the game drew.
        dist = far;
        col = skyGradient(dirW, sunW, moonW, rainStrength, 1.0);
        #ifdef CLOUDS
        vec3 cAmb = mix(vec3(0.03, 0.04, 0.08), vec3(0.55, 0.65, 0.85), day);
        cAmb += vec3(0.25, 0.12, 0.08) * exp(-sunW.y * sunW.y * 28.0) * 0.6;
        vec4 cl = cloudLayer(dirW, cameraPosition, sunW, frameTimeCounter, rainStrength, cAmb);
        col = mix(col, cl.rgb, cl.a);
        #endif
    } else {
        col = dec(src.rgb);
        dist = length(vp);

        // ---- Depth AO: 4 taps, rotated per pixel, radius ~0.3 block projected to the screen.
        #ifdef AMBIENT_OCCLUSION
        if (depth > 0.56) {                           // skip the held item
            float zc = linZ(depth);
            float rad = clamp(0.30 * gbufferProjection[1][1] / zc, 2.0 / viewHeight, 0.035);
            vec2 asp = vec2(viewHeight / viewWidth, 1.0);
            float a0 = ign(gl_FragCoord.xy) * 6.2831853;
            float occ = 0.0;
            for (int i = 0; i < 4; i++) {
                float fi = float(i);
                float a = a0 + fi * 1.5707963;
                vec2 off = vec2(cos(a), sin(a)) * asp * rad * (0.6 + 0.4 * fi * 0.3333);
                float zs = linZ(texture2D(depthtex0, texcoord + off).r);
                float dz = zc - zs;                    // > 0 when the neighbour is in front of us
                occ += clamp(dz * 2.0 - 0.06, 0.0, 1.0) * (1.0 - smoothstep(0.7, 2.0, dz));
            }
            col *= mix(1.0, 1.0 - occ * 0.25 * 0.9, 0.85);
        }
        #endif

        // ---- Aerial perspective: haze coloured by the sky in that direction (so it glows toward the sun).
        float skyAtt = smoothstep(0.0, 0.75, src.a);
        vec3 feet = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz;
        float worldY = feet.y + cameraPosition.y;
        float hf = exp(-max(worldY - 60.0, 0.0) * 0.012);
        float haze = 1.0 - exp(-dist * 0.0016 * (1.0 + rainStrength * 4.0) * FOG_DENSITY * mix(0.35, 1.0, hf));
        float edge = smoothstep(0.70, 1.0, dist / far);
        vec3 fdir = normalize(vec3(dirW.x, max(dirW.y, 0.0) * 0.5, dirW.z));
        vec3 fogCol = skyGradient(fdir, sunW, moonW, rainStrength, 0.0);
        fogCol *= mix(0.04, 1.0, skyAtt);
        float f = 1.0 - (1.0 - haze * mix(0.15, 1.0, skyAtt)) * (1.0 - edge);
        col = mix(col, fogCol, clamp(f, 0.0, 1.0));
    }

    // ---- Sun shafts: 6 depth taps toward the sun, only when looking roughly at it.
    #ifdef GODRAYS
    if (isEyeInWater == 0) {
        vec3 sunV = normalize(sunPosition);
        float facing = max(dot(dirV, sunV), 0.0);
        vec4 sc = gbufferProjection * vec4(sunPosition, 1.0);
        if (facing > 0.25 && sc.w > 0.0 && sunW.y > -0.05) {
            vec2 suv = sc.xy / sc.w * 0.5 + 0.5;
            vec2 stepv = (suv - texcoord) * (0.8 / 6.0);
            vec2 uv = texcoord + stepv * ign(gl_FragCoord.xy);
            float acc = 0.0;
            for (int i = 0; i < 6; i++) {
                uv += stepv;
                acc += step(0.9999, texture2D(depthtex0, clamp(uv, vec2(0.001), vec2(0.999))).r);
            }
            acc *= (1.0 / 6.0);
            float k = pow(facing, 4.0) * smoothstep(-0.05, 0.25, sunW.y) * (1.0 - rainStrength);
            col += sunColorAt(sunW.y) * acc * k * 0.30;
        }
    }
    #endif

    // ---- Underwater / lava: per-channel absorption + in-scatter, the cheap volumetric look.
    if (isEyeInWater == 1) {
        float d = (depth >= 1.0) ? 80.0 : dist;
        vec3 scatter = vec3(0.02, 0.10, 0.16) * (0.25 + 0.75 * clamp(sunW.y + 0.3, 0.0, 1.0));
        col *= exp(-d * vec3(0.30, 0.10, 0.05));
        col += scatter * (1.0 - exp(-d * 0.08));
    } else if (isEyeInWater == 2) {
        float d = (depth >= 1.0) ? 10.0 : dist;
        col = mix(col, vec3(0.8, 0.3, 0.05), 1.0 - exp(-d * 1.5));
    }

    gl_FragData[0] = vec4(enc(col), 1.0);
}

/* DRAWBUFFERS:0 */
