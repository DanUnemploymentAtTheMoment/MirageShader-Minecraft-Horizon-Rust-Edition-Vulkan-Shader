#version 330 compatibility
uniform sampler2D texture;
in vec4 vColor;
in vec2 vTex;
void main() {
    vec4 t = texture2D(texture, vTex) * vColor;
    gl_FragData[0] = vec4(t.rgb, t.a);
}

/* DRAWBUFFERS:0 */
